export BACKUP_CONFIG_PATHS="/home/bert/.config/scripts/backup_config_paths.txt"
export CONFIG_BACKUP_REPO="/home/bert/Work/linux_configs"