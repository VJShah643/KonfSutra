vim.cmd("language en_US")
vim.cmd("set expandtab")
vim.cmd("set tabstop=2")
vim.cmd("set softtabstop=2")
vim.cmd("set shiftwidth=2")
vim.cmd("set nu")
vim.g.mapleader = " "
--vim.wo.relativenumber = true