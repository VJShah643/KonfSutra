#!/bin/sh

i3-msg "exec --no-startup-id google-chrome-stable"; i3-msg "exec --no-startup-id thunar"; i3-msg "exec --no-startup-id spotify"; i3-msg "exec --no-startup-id firefox";