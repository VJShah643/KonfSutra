#alias
alias vim=nvim
alias rewire="vim ~/.i3/config"
alias livealpha="source ~/Work/envs/py313_env_alpha/bin/activate"
alias backup_configs="python ~/.config/scripts/backup_config_paths.py"