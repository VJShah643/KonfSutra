---@type ChadrcConfig 
 local M = {}
 M.ui = {theme = 'catppuccin'}
 return M